//
//  TextViewController.swift
//  Psychologist
//
//  Created by Mark Ambrose on 27/02/2015.
//  Copyright (c) 2015 Market Driven Software. All rights reserved.
//

import UIKit

class TextViewController: UIViewController
{
    @IBOutlet weak var textView: UITextView!
        {
        didSet{
            textView.text=text
        }
    }
    
    var text: String = ""
        {
        didSet{
            textView?.text = text // use ? as this will be called before textView is set ie nil
        }
    }

}
