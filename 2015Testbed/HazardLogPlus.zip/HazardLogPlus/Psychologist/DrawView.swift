//
//  DrawView.swift
//  HazardLogPlus
//
//  Created by Mark Ambrose on 06/03/2015.
//  Copyright (c) 2015 Market Driven Software. All rights reserved.
//

import UIKit

class DrawView: UIView {
    var lines: [ Line ] = []
    var lastPoint: CGPoint!
    var drawView: DrawView!
    var drawColor : UIColor!
    
 //   init(coder aDecoder: NSCoder!) {
 //       super.init(coder: aDecoder)
 //   }
    
    override func touchesBegan(touches: (NSSet!), withEvent event: (UIEvent!)) {
        lastPoint = touches!.anyObject()?.locationInView(self)
    }
    
    override func touchesMoved(touches: (NSSet!), withEvent event:(UIEvent!)) {
        var newPoint = touches.anyObject()?.locationInView(self)
        lines.append(Line(start: lastPoint, end: newPoint!))
        lastPoint = newPoint
                                                    
        self.setNeedsDisplay()
    }
    
//

override func drawRect(rect: CGRect)
{
    var context = UIGraphicsGetCurrentContext()
    CGContextBeginPath(context)
    for line in lines {
        CGContextMoveToPoint(context, line.start.x, line.start.y)
        CGContextAddLineToPoint(context, line.end.x, line.end.y)
    }
    CGContextSetRGBFillColor(context,1,1,0,1)
    CGContextStrokePath(context)
}


    
    @IBAction func clearTapped() {
        var theDrawView : DrawView = drawView as DrawView
        theDrawView.lines = []
        theDrawView.setNeedsDisplay()
    }
    
   
    @IBAction func colorTapped(button: UIButton!) {
       var theDrawView : DrawView = self
        // drawView // as DrawView
        var color : UIColor!
        if button.titleLabel?.text == "Red" {
            color = UIColor.redColor()
        } else if button.titleLabel?.text == "Black" {
            color = UIColor.blackColor()
        }
        theDrawView.drawColor = color
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController
        // Pass the selected object to the new view controller.
    }
    */

}
