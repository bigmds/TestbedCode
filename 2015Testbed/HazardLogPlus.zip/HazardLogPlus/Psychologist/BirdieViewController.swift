//
//  BirdieViewController.swift
//  HazardLogPlus
//
//  Created by Mark Ambrose on 11/03/2015.
//  Copyright (c) 2015 Market Driven Software. All rights reserved.
//

import Foundation
import UIKit

class BirdieVieontroller : UIViewController
{

    @IBAction func handleTap(recogizer: UITapGestureRecognizer) {
        
    }
    
    
}
