//
//  Symbol.swift
//  201ISAE
//
//  Created by Mark Ambrose on 02/03/2015.
//  Copyright (c) 2015 Market Driven Software. All rights reserved.
//

import Foundation
import UIKit

class Symbol
{
    
    var X:Int = 0
    var Y:Int = 0
    var Height:Int = 0
    var Width:Int = 0
    
    var lineWidth:CGFloat = 1

    var ID: String = "Naked Symbol"
    
    var Worksheet: Int = 0
    
    var Description: String = "Naked Symbol"
    
    func Draw()
    {
    }

}