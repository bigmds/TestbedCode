//
//  CriticalEvent.swift
//  Psychologist
//
//  Created by Mark Ambrose on 03/03/2015.
//  Copyright (c) 2015 Market Driven Software. All rights reserved.
//

import Foundation

class CriticalEvent: Symbol
{

    override func Draw()
    {
    }
    
}