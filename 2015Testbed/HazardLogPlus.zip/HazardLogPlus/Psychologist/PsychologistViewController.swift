//
//  ViewController.swift
//  Psychologist
//
//  Created by Mark Ambrose on 25/02/2015.
//  Copyright (c) 2015 Market Driven Software. All rights reserved.
//

import UIKit

class PsychologistViewController: UIViewController
{

    @IBAction func nothing(sender: UIButton) {
    // coded way of calling segue
    // but still need to create segue in storyboard
    // so drag from yellow ctlr icon at top of vc (type show detl)
        performSegueWithIdentifier("nothing", sender: nil)
    // this still now goes through prepareforsegue below
    }
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        var destination = segue.destinationViewController as? UIViewController
        if let navCon = destination as? UINavigationController {
            destination = navCon.visibleViewController
        }
        if let hvc = destination as? HappinessViewController {
            if let identifier = segue.identifier{
                switch identifier {
                    case "sad": hvc.happiness=0
                    case "happy":hvc.happiness=100
                    case "nothing": hvc.happiness=25
                    default: hvc.happiness=50
                }
            }
        }
    }

}

