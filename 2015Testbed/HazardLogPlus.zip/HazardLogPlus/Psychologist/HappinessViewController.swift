//
//  HappinessViewController.swift
//  Happiness
//
//  Created by Mark Ambrose on 19/02/2015.
//  Copyright (c) 2015 Market Driven Software. All rights reserved.
//

import UIKit

class HappinessViewController: UIViewController, FaceViewDataSource
{

    @IBOutlet weak var faceView: FaceView! {
        didSet {
            faceView.dataSource = self
            faceView.addGestureRecognizer(UIPinchGestureRecognizer(target: faceView, action: "scale:"))
        }
    }
    
    // delegation example below
    
    private struct Constants{
        static let HappinessGestureScale: CGFloat = 4
    }
    
    var happiness: Int = 70
        { // 0=very sad 100=ecstatic
        didSet{
        happiness = min(max(happiness, 0),100)
        println("happiness = \(happiness)")
            
        updateUI()
        }
    }
    
    @IBAction func changeHappiness(gesture: UIPanGestureRecognizer) {
        switch gesture.state {
        case .Ended: fallthrough
        case .Changed:
            let translation = gesture.translationInView(faceView)
            let happinessChange = -Int(translation.y / Constants.HappinessGestureScale)
            if happiness != 0 {
                happiness += happinessChange
                gesture.setTranslation(CGPointZero, inView: faceView )
            }
        default: break
        }
    
    }
//    
    private func updateUI() {
        faceView?.setNeedsDisplay() // force redraw // if nil ignore
        title = "\(happiness)"
    }
//    
    func smilinessForFaceView(sender: FaceView) -> Double? {
        // intepret model from view
        return Double(happiness-50)/50

     }
}
