//
//  Worksheet.swift
//  Psychologist
//
//  Created by Mark Ambrose on 03/03/2015.
//  Copyright (c) 2015 Market Driven Software. All rights reserved.
//

import Foundation


class Worksheet
{
    var title : String = "No Title"
    var owner : String = "No Owner"
   
 //   var symbols : Symbol[]
    

    
}