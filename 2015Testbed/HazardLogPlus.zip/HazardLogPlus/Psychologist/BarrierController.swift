//
//  BarrierController.swift
//  Psychologist
//
//  Created by Mark Ambrose on 04/03/2015.
//  Copyright (c) 2015 Market Driven Software. All rights reserved.
//

import Foundation
import UIKit

class BarrierViewController: UIViewController
{
    
}