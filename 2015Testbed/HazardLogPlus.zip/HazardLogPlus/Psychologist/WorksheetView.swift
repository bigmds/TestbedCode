//
//  WorksheetView.swift
//  HazardLogPlus
//
//  Created by Mark Ambrose on 06/03/2015.
//  Copyright (c) 2015 Market Driven Software. All rights reserved.
//

import Foundation
import UIKit

@IBDesignable

class WorksheetView: UIView
{
    @IBInspectable
    var x: Int = 100 { didSet {setNeedsDisplay()}}
    @IBInspectable
    var y: Int = 100 { didSet {setNeedsDisplay()}}
    @IBInspectable
    var height: Int = 100 { didSet {setNeedsDisplay()}}
    @IBInspectable
    var width: Int = 240 { didSet {setNeedsDisplay()}}
    @IBInspectable
    var cdescription: String = "Consequence: Description" { didSet {setNeedsDisplay()}}
    @IBInspectable
    var photoFilename: String = "alllights.png"{ didSet {setNeedsDisplay()}}
    
//    
//    func dragged(gesture: UIPanGestureRecognizer) {
//        
//        let translation = gesture.translationInView(self.view)
//        let label = gesture.view!
//        
//        xFromCenter += translation.x
//        
//        //absolute value, to always positive value so the label isn't turned upside down when moved to the left (left is negative on any axis). 1 divided by negative will give upside down result when used for stretch
//        var scaleValue = min(95/abs(xFromCenter), 1.2)
//        
//        label.center = CGPoint(x: label.center.x + translation.x, y: label.center.y + translation.y)
//        
//        gesture.setTranslation(CGPoint(x: 0, y: 0), inView: self.view)
//        
//        var rotation: CGAffineTransform = CGAffineTransformMakeRotation(xFromCenter/200)
//        var scale: CGAffineTransform = CGAffineTransformScale(rotation, scaleValue, scaleValue)
//        
//        label.transform = scale
//        
//        if gesture.state == UIGestureRecognizerState.Ended {
//            if label.center.x < 75 {
//                println("not chosen")
//            } else if label.center.x > self.view.bounds.width - 75 {
//                println("chosen")
//            } else {
//                UIView.animateWithDuration(0.3, animations: { () -> Void in
//                    label.center = self.originalCenter
//                    label.transform = CGAffineTransformIdentity
//                })
//                
//                xFromCenter = 0
//            }
//        }
//    }
//    
    
    override func drawRect(r2ct: CGRect)
    {
        var spacer = 5
        
        // BOX CONSTRUCTION
        
        // outline box
        let Shape =   CGRect(   x: x,
            y: y,
            width: width,
            height: height)
        let Path  = UIBezierPath(rect: Shape)
        Path.lineWidth = 2 // lineWidth
        Path.stroke()
        
        // TEXT
        
        let text: String  = cdescription
        let fieldColor: UIColor = UIColor.blackColor()
        let fieldFont = UIFont(name: "Helvetica Neue", size: 12)
        var paraStyle = NSMutableParagraphStyle()
        
        paraStyle.lineSpacing = 6.0
        
        var skew = 0.2
        
        var attributes: NSDictionary = [
            NSForegroundColorAttributeName: fieldColor,
            NSParagraphStyleAttributeName: paraStyle,
            NSObliquenessAttributeName: skew,
            NSFontAttributeName: fieldFont!
        ]
        
        var textX: CGFloat = CGFloat(x + spacer)
        var textY: CGFloat = CGFloat(y + spacer)
        var textHeight: CGFloat = CGFloat(height)
        var textWidth: CGFloat = CGFloat(width)
        
        text.drawInRect(CGRectMake( textX , textY, textWidth, textHeight), withAttributes: attributes)
        
        // RECEIVER CONNECTOR
        
        let nodeRadius = 5
        let receiverX:Int = x + (width / 2)
        let receiverY:Int = y + height + nodeRadius
        let nodeCentre: CGPoint  = CGPoint(x: receiverX, y: receiverY)
        
        let receiverNodePath = UIBezierPath(arcCenter: nodeCentre,
            radius: CGFloat(nodeRadius),
            startAngle: 0,
            endAngle: CGFloat(2*M_PI),
            clockwise: true)
        
        var colorNode:UIColor = UIColor.blueColor()
        colorNode.set()
        receiverNodePath.stroke()
        
        // IMAGES
        // LOGO
        
        var photoHeight: Int = 40
        var photoWidth: Int = 40
        
        let myImage = UIImage(named: "greenarrow.png")
        let imageRect = CGRectMake(CGFloat(x+width-photoWidth-spacer),
            CGFloat(y+height-photoHeight-spacer),
            CGFloat(photoWidth),
            CGFloat(photoHeight))
        // Fill the rectangle with blue
        UIColor(red: 0.20, green: 0.60, blue: 0.80, alpha: 1.0).setFill()
        UIRectFill( imageRect );
        
        myImage?.drawInRect(imageRect)
        
        // PHOTO
        let photoImage = UIImage(named: photoFilename)
        let photoRect = CGRectMake( CGFloat(x+spacer),
            CGFloat(y+height-photoHeight-spacer),
            CGFloat(photoWidth),
            CGFloat(photoHeight))
        // Fill the rectangle with orange
        UIColor(red: 0.90, green: 0.50, blue: 0.20, alpha: 1.0).setFill()
        UIRectFill(photoRect);
        
        photoImage?.drawInRect(photoRect)
        
    } // end of DrawRect
    
    
}


