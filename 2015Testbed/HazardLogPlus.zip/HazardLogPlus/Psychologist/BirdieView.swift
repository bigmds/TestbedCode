//
//  BirdieView.swift
//  HazardLogPlus
//
//  Created by Mark Ambrose on 10/03/2015.
//  Copyright (c) 2015 Market Driven Software. All rights reserved.
//

import Foundation
import UIKit

@IBDesignable

class BirdieView: UIView
{
    @IBInspectable
    var lineWidth: CGFloat = 0.5 { didSet {setNeedsDisplay()}} // an observer (like a trigger)!
    @IBInspectable
    var color: UIColor = UIColor.blueColor() { didSet {setNeedsDisplay()}}
    @IBInspectable
    var scale: CGFloat = 0.90 { didSet {setNeedsDisplay()}}
    
    @IBInspectable
    var barrierX: Int = 100 { didSet {setNeedsDisplay()}}
    @IBInspectable
    var barrierY: Int = 100 { didSet {setNeedsDisplay()}}
    @IBInspectable
    var barrierHeight: Int = 100 { didSet {setNeedsDisplay()}}
    @IBInspectable
    var barrierWidth: Int = 200 { didSet {setNeedsDisplay()}}
    
    let conditionHeight: Int = 33
    let conditionWidth: Int = 100 // (Width/2)
    
    @IBInspectable
    var barrierSuccessText: String = "Success 63%" { didSet {setNeedsDisplay()}}
    @IBInspectable
    var barrierFailText: String = "Fail 37%" { didSet {setNeedsDisplay()}}
    @IBInspectable
    var barrierDescription: String = "Barrier Description" { didSet {setNeedsDisplay()}}
    
    
    func scale(gesture: UIPinchGestureRecognizer)
    {
        if gesture.state == .Changed
        {
            scale *= gesture.scale
            gesture.scale = 1
        }
        
    }

    func DrawNestCell(cellNo: Int, imageName: String) {
        let myImage = UIImage(named: imageName)
        
        var imageHeight: CGFloat = 40
        var imageWidth: CGFloat = 55

        var cellPosnX: [CGFloat] =
                [100,150,200,100,150,200,100,150,200]
        
        var cellPosnY: [CGFloat] =
                [150,150,150,190,190,190,230,230,230]
        
        let imageRect = CGRectMake (cellPosnX[cellNo],
                                    cellPosnY[cellNo],
                                    imageWidth,
                                    imageHeight)
        
        
        // Fill the rectangle
        UIColor(red: 0.30,
                green: 0.50,
                blue: 0.20,
                alpha: 1.0).setFill()
        //
        UIRectFill( imageRect );
        myImage?.drawInRect(imageRect)
        
    }
    
    override func drawRect(r2ct: CGRect)
    {
        // BOX CONSTRUCTION
        
//        // RED fail condition
//        let conditionShape2 = CGRect(   x: barrierX+1,
//            y: barrierY+1,
//            width: conditionWidth-2,
//            height: conditionHeight-1)
//        let barrierPath2  = UIBezierPath(rect: conditionShape2)
//        var color2:UIColor = UIColor.redColor()
//        color2.set()
//        barrierPath2.lineWidth = lineWidth
//        barrierPath2.stroke()
//        
//        // GREEN success condition
//        let conditionShape1 = CGRect(   x: barrierX+conditionWidth+2,
//            y: barrierY+1,
//            width: conditionWidth-3,
//            height: conditionHeight-1)
//        let barrierPath1  = UIBezierPath(rect: conditionShape1)
//        var color1:UIColor =  UIColor(red: 0.30, green: 0.50, blue: 0.20, alpha: 1.0)
//        // UIColor.greenColor()?
//        color1.set()
//        barrierPath1.lineWidth = lineWidth
//        barrierPath1.stroke()
//        
//        //middle line
//        let midlineShape = CGRect(x: barrierX+conditionWidth, y: barrierY, width: 1, height: conditionHeight)
//        let midlinePath  = UIBezierPath(rect: midlineShape)
//        midlinePath.lineWidth = lineWidth
//        var color:UIColor = UIColor.blackColor()
//        color.set()
//        midlinePath.stroke()
//        
//        // barrier outline box
//        let barrierShape = CGRect(x: barrierX, y: barrierY, width: barrierWidth, height: barrierHeight)
//        let barrierPath  = UIBezierPath(rect: barrierShape)
//        barrierPath.lineWidth = lineWidth
//        barrierPath.stroke()
//        // TEXT
//        let text: String  = barrierDescription // "Barrier Description"
//        let fieldColor: UIColor = UIColor.blackColor()
//        let fieldFont = UIFont(name: "Helvetica Neue", size: 12)
//        var paraStyle = NSMutableParagraphStyle()
//        paraStyle.lineSpacing = 6.0
//        var skew = 0.2
//        
//        // description text
//        var attributes: NSDictionary = [
//            NSForegroundColorAttributeName: fieldColor,
//            NSParagraphStyleAttributeName: paraStyle,
//            NSObliquenessAttributeName: skew,
//            NSFontAttributeName: fieldFont!
//        ]
//        
//        var textX: CGFloat = CGFloat(barrierX + 5)
//        var textY: CGFloat = CGFloat(barrierY + conditionHeight)
//        var textHeight = CGFloat(barrierY + barrierHeight)
//        var textWidth = CGFloat(barrierX + barrierWidth)
//        
//        text.drawInRect(CGRectMake( textX , textY, textHeight, textWidth), withAttributes: attributes)
//        
//        // RED fail text
//        var attributesSuccess: NSDictionary = [
//            NSForegroundColorAttributeName: UIColor.redColor(),
//            NSParagraphStyleAttributeName: paraStyle,
//            NSObliquenessAttributeName: 0,
//            NSFontAttributeName: fieldFont!
//        ]
//        barrierFailText.drawInRect(CGRectMake(110.0, 100.0, 130.0, 250.0), withAttributes: attributesSuccess)
//        
//        // GREEN success text  UIColor.darkGrayColor(),
//        var attributesFail: NSDictionary = [
//            NSForegroundColorAttributeName: UIColor(red: 0.30, green: 0.50, blue: 0.20, alpha: 1.0),
//            NSParagraphStyleAttributeName: paraStyle,
//            NSObliquenessAttributeName: 0,
//            NSFontAttributeName: fieldFont!
//        ]
//        barrierSuccessText.drawInRect(CGRectMake(210.0, 100.0, 130.0, 250.0), withAttributes: attributesFail)
//        
//        // SENDERS CONNECTORS
//        let imageSize = CGSize(width: 10, height: 10)
//        
//        let image = drawSenderImage(imageSize)
//        
//        var senderX : CGFloat = 0
//        senderX = CGFloat(barrierX + (conditionWidth / 2))
//        let c1Rect = CGRectMake(senderX,90,10,10) // was 140
//        image.drawInRect(c1Rect)
//        
//        senderX = CGFloat(barrierX + conditionWidth + (conditionWidth / 2))
//        let image2 = drawSenderImage(imageSize)
//        let c2Rect = CGRectMake(senderX,90,10,10) // was 240
//        image2.drawInRect(c2Rect)
//        
//        // RECIEVER CONNECTOR
//        let nodeRadius = 5
//        let receiverX:Int = barrierX + conditionWidth
//        let receiverY:Int = 210 - nodeRadius
//        let nodeCentre: CGPoint  = CGPoint(x: receiverX, y: receiverY)
//        
//        let receiverNodePath = UIBezierPath(arcCenter: nodeCentre,
//            radius: CGFloat(nodeRadius),
//            startAngle: 0,
//            endAngle: CGFloat(2*M_PI),
//            clockwise: true)
//        
//        var colorNode:UIColor = UIColor.blueColor()
//        colorNode.set()
//        receiverNodePath.stroke()
        
        // PHOTO IMAGE 40x55
        
        DrawNestCell ( 0, imageName: "bird100.png")
        DrawNestCell ( 1, imageName: "bird100.png")
        DrawNestCell ( 2, imageName: "bird100.png")
        DrawNestCell ( 3, imageName: "bird100.png")
        DrawNestCell ( 4, imageName: "bird100.png")
        DrawNestCell ( 5, imageName: "bird100.png")
        DrawNestCell ( 6, imageName: "bird100.png")
        DrawNestCell ( 7, imageName: "bird100.png")
        DrawNestCell ( 8, imageName: "bird100.png")

    }
    

    
    
    
    
    func DrawImage(image: String)
    {
        
        let data = NSData (contentsOfFile: image )
        // we create a UIImage out of it
        let image = UIImage(data: data!)
        // our rectangle for the drawing size
        let rect = CGRectMake(80, 110, 50, 100)
        // we create our graphics context at the size of our image
        UIGraphicsBeginImageContextWithOptions(CGSize(width: rect.width, height: rect.height), true, 0)
        // we draw our image to the graphics context
        image?.drawInRect(rect) //`.drawInRect(rect)
    }
    
    
    func drawSenderImage(size: CGSize) -> UIImage {
        // Setup our context
        let bounds = CGRect(origin: CGPoint.zeroPoint, size: size)
        let opaque = false
        let scale: CGFloat = 0
        UIGraphicsBeginImageContextWithOptions(size, opaque, scale)
        let context = UIGraphicsGetCurrentContext()
        
        // Setup complete, do drawing here
        CGContextSetStrokeColorWithColor(context, UIColor.redColor().CGColor)
        CGContextSetLineWidth(context, 2.0)
        
        CGContextStrokeRect(context, bounds)
        
        CGContextBeginPath(context)
        CGContextMoveToPoint(context, CGRectGetMinX(bounds), CGRectGetMinY(bounds))
        CGContextAddLineToPoint(context, CGRectGetMaxX(bounds), CGRectGetMaxY(bounds))
        CGContextMoveToPoint(context, CGRectGetMaxX(bounds), CGRectGetMinY(bounds))
        CGContextAddLineToPoint(context, CGRectGetMinX(bounds), CGRectGetMaxY(bounds))
        CGContextStrokePath(context)
        
        // Drawing complete, retrieve the finished image and CLEANUP
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }
    
    
    
    func drawPlayPathTo(context: CGContextRef, boundedBy rect: CGRect)
    {
        //CGContextSetFillColorWithColor(context, UIColor.blackColor().CGColor)
        
        CGContextMoveToPoint(context, rect.width / 4, rect.height / 4)
        
        CGContextAddLineToPoint(context, rect.width * 3 / 4, rect.height / 2)
        
        CGContextAddLineToPoint(context, rect.width / 4, rect.height * 3 / 4)
        
        CGContextAddLineToPoint(context, rect.width / 4, rect.height / 4)
        
        CGContextFillPath(context)
    }
    
    
    func degree2radian(a:CGFloat)->CGFloat {
        let b = CGFloat(M_PI) * a/180
        return b
    }
    
    func polygonPointArray(sides:Int,x:CGFloat,y:CGFloat,radius:CGFloat)->[CGPoint] {
        let angle = degree2radian(360/CGFloat(sides))
        let cx = x // x origin
        let cy = y // y origin
        let r  = radius // radius of circle
        var i = 0
        var points = [CGPoint]()
        while i <= sides {
            var xpo = cx + r * cos(angle * CGFloat(i))
            var ypo = cy + r * sin(angle * CGFloat(i))
            points.append(CGPoint(x: xpo, y: ypo))
            i++;
        }
        return points
    }
    
}


