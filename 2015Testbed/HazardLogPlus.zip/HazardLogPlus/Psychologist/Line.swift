//
//  Line.swift
//  HazardLogPlus
//
//  Created by Mark Ambrose on 09/03/2015.
//  Copyright (c) 2015 Market Driven Software. All rights reserved.
//

import UIKit

class Line {
    var start: CGPoint
    var end: CGPoint
    
    init (start _start: CGPoint, end _end : CGPoint) {
        start = _start
        end = _end
    }
    
}