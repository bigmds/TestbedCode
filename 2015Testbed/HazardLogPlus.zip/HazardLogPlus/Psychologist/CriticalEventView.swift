//
//  CriticalEventView.swift
//  HazardLogPlus
//
//  Created by Mark Ambrose on 05/03/2015.
//  Copyright (c) 2015 Market Driven Software. All rights reserved.
//

import Foundation
import UIKit

@IBDesignable

class CriticalEventView: UIView
{
    @IBInspectable
    var scale: CGFloat = 0.90 { didSet {setNeedsDisplay()}}
    
    
    @IBInspectable
    var ceX: Int = 100 { didSet {setNeedsDisplay()}}
    @IBInspectable
    var ceY: Int = 100 { didSet {setNeedsDisplay()}}
    @IBInspectable
    var ceHeight: Int = 100 { didSet {setNeedsDisplay()}}
    @IBInspectable
    var ceWidth: Int = 200 { didSet {setNeedsDisplay()}}
    @IBInspectable
    var ceDescription: String = "Critical Event: Description"
        { didSet {setNeedsDisplay()}}
    @IBInspectable
    var cePhotoName: String = "default_photo.png"
        { didSet {setNeedsDisplay()}}
    
    var ceOuterGap: Int  = 20
    
    let conditionHeight: Int = 33
    let conditionWidth: Int = 100
    
    override func drawRect(r2ct: CGRect)
    {
        // BOX CONSTRUCTION
        
        // outline box
        let ceShape = CGRect(x: ceX,
                             y: ceY,
                             width: ceWidth,
                                  height: ceHeight)
        let cePath  = UIBezierPath(rect: ceShape)
        cePath.lineWidth = 1 // lineWidth
        cePath.stroke()

        let ceShapeOuter = CGRect( x: ceX - ceOuterGap,
                                        y: ceY,
                                        width: ceWidth + (ceOuterGap * 2),
                                        height: ceHeight)
        let ceOuterPath  = UIBezierPath(rect: ceShapeOuter)
        ceOuterPath.lineWidth = 1 // lineWidth
        ceOuterPath.stroke()

        // TEXT
        
        let text: String  = ceDescription
        let fieldColor: UIColor = UIColor.blackColor()
        let fieldFont = UIFont(name: "Helvetica Neue", size: 12)
        var paraStyle = NSMutableParagraphStyle()
        paraStyle.lineSpacing = 6.0
        var skew = 0.2
        
        var attributes: NSDictionary = [
            NSForegroundColorAttributeName: fieldColor,
            NSParagraphStyleAttributeName: paraStyle,
            NSObliquenessAttributeName: skew,
            NSFontAttributeName: fieldFont!
        ]

        var textX: CGFloat = CGFloat(ceX + 5)
        var textY: CGFloat = CGFloat(ceY + 10)
        var textHeight = CGFloat(ceHeight)
        var textWidth = CGFloat(ceWidth)
        
        text.drawInRect(CGRectMake( textX , textY, textWidth, textHeight), withAttributes: attributes)
        
        // HAS ONE SENDERS CONNECTOR
        
        var senderHeight: Int = 10
        var senderWidth: Int = 10
        
        let imageSize = CGSize(width: senderWidth, height: senderHeight)
        let image = drawSenderImage(imageSize)
        
        var senderX : CGFloat = 0
        senderX = CGFloat(ceX + ceWidth / 2 - (senderWidth / 2))
        let c1Rect = CGRectMake(senderX,
                                90,
                                CGFloat(senderWidth),
                                CGFloat(senderHeight))

        image.drawInRect(c1Rect)
        
        // SAFETY IMAGE
        var photoHeight: Int = 40
        var photoWidth: Int = 40
        
        let myImage = UIImage(named: "safety.png")
        let imageRect = CGRectMake(CGFloat(ceX+ceWidth-photoWidth-5),
                                   CGFloat(ceY+ceHeight-photoHeight-5),
                                   CGFloat(photoWidth),
                                   CGFloat(photoHeight))
        // Fill the rectangle with grey
        UIColor(red: 0.20, green: 0.60, blue: 0.80, alpha: 1.0).setFill()
        UIRectFill( imageRect );
        
        myImage?.drawInRect(imageRect)

        // PHOTOIMAGE
        let photoImage = UIImage(named: cePhotoName)
        let photoRect = CGRectMake( CGFloat(ceX+5),
                                    CGFloat(ceY+ceHeight-photoHeight-5),
                                    CGFloat(photoWidth),
                                    CGFloat(photoHeight))
        // Fill the rectangle with green
        UIColor(red: 0.30, green: 0.50, blue: 0.20, alpha: 1.0).setFill()
        UIRectFill( photoRect );
        
        photoImage?.drawInRect(photoRect)

    } // end of DrawRect
    
    
    
    
    func xxxDrawImage(image: String)
    {
        
        let data = NSData (contentsOfFile: image )
        // we create a UIImage out of it
        let image = UIImage(data: data!)
        // our rectangle for the drawing size
        let rect = CGRectMake(100, 100, 50, 100)
        // we create our graphics context at the size of our image
        UIGraphicsBeginImageContextWithOptions(CGSize(width: rect.width, height: rect.height), true, 0)
        // we draw our image to the graphics context
        image?.drawInRect(rect) //`.drawInRect(rect)
    }
    
    
    func drawSenderImage(size: CGSize) -> UIImage {
        // Setup our context
        let bounds = CGRect(origin: CGPoint.zeroPoint, size: size)
        let opaque = false
        let scale: CGFloat = 0
        UIGraphicsBeginImageContextWithOptions(size, opaque, scale)
        let context = UIGraphicsGetCurrentContext()
        
        // Setup complete, do drawing here
        CGContextSetStrokeColorWithColor(context, UIColor.redColor().CGColor)
        CGContextSetLineWidth(context, 2.0)
        
        CGContextStrokeRect(context, bounds)
        
        CGContextBeginPath(context)
        CGContextMoveToPoint(context, CGRectGetMinX(bounds), CGRectGetMinY(bounds))
        CGContextAddLineToPoint(context, CGRectGetMaxX(bounds), CGRectGetMaxY(bounds))
        CGContextMoveToPoint(context, CGRectGetMaxX(bounds), CGRectGetMinY(bounds))
        CGContextAddLineToPoint(context, CGRectGetMinX(bounds), CGRectGetMaxY(bounds))
        CGContextStrokePath(context)
        
        // Drawing complete, retrieve the finished image and CLEANUP
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }

    func drawPlayPathTo(context: CGContextRef, boundedBy rect: CGRect)
    {
        //CGContextSetFillColorWithColor(context, UIColor.blackColor().CGColor)
        
        CGContextMoveToPoint(context, rect.width / 4, rect.height / 4)
        
        CGContextAddLineToPoint(context, rect.width * 3 / 4, rect.height / 2)
        
        CGContextAddLineToPoint(context, rect.width / 4, rect.height * 3 / 4)
        
        CGContextAddLineToPoint(context, rect.width / 4, rect.height / 4)
        
        CGContextFillPath(context)
    }
    
    
    func degree2radian(a:CGFloat)->CGFloat {
        let b = CGFloat(M_PI) * a/180
        return b
    }
    
    func polygonPointArray(sides:Int,x:CGFloat,y:CGFloat,radius:CGFloat)->[CGPoint] {
        let angle = degree2radian(360/CGFloat(sides))
        let cx = x // x origin
        let cy = y // y origin
        let r  = radius // radius of circle
        var i = 0
        var points = [CGPoint]()
        while i <= sides {
            var xpo = cx + r * cos(angle * CGFloat(i))
            var ypo = cy + r * sin(angle * CGFloat(i))
            points.append(CGPoint(x: xpo, y: ypo))
            i++;
        }
        return points
    }
    
}


