//
//  Barrier.swift
//  201ISAE
//
//  Created by Mark Ambrose on 02/03/2015.
//  Copyright (c) 2015 Market Driven Software. All rights reserved.
//

import Foundation
import UIKit

class Barrier:Symbol
{
    
    override func Draw()
    {
//    let barrierH: Int = 300
//    let barrierW: Int = 400
//    let barrierX: Int = 300
//    let barrierY: Int = 100
    
        
    // for parent Symol class
    X = 300
    Y = 400
    Height = 300
    Width = 100
    let conditionH: Int = 100
    let conditionW: Int = (Width/2)
    
    let successText = "success"
    let failText = "fail"
        
  //  let lineWidth:CGFloat = 1
    
    // london bridge 18:03 20 mins late then cancelled 2 feb 15
        
        
    // green condition
    let conditionShape1 = CGRect(x: X, y: Y, width: Width, height: conditionH)
    let barrierPath1  = UIBezierPath(rect: conditionShape1)
    var color1:UIColor = UIColor.greenColor()
    color1.set()
    barrierPath1.lineWidth = lineWidth
    barrierPath1.stroke()
    // red condition
    let conditionShape2 = CGRect(x: X, y: Y, width: conditionW, height: conditionH)
    let barrierPath2  = UIBezierPath(rect: conditionShape2)
    var color2:UIColor = UIColor.redColor()
    color2.set()
    barrierPath2.lineWidth = lineWidth
    barrierPath2.stroke()
    //middle line
    let midlineShape = CGRect(x: X+conditionW, y: Y, width: 1, height: conditionH)
    let midlinePath  = UIBezierPath(rect: midlineShape)
    midlinePath.lineWidth = lineWidth
    var color:UIColor = UIColor.blackColor()
    color.set()
    midlinePath.stroke()
    // box
    let barrierShape = CGRect(x: X, y: Y, width: Width, height: Height)
    let barrierPath  = UIBezierPath(rect: barrierShape)
    barrierPath.lineWidth = lineWidth
    barrierPath.stroke()
    }
    
    
    
    
}